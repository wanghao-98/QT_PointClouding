#include "ProjectIndices.h"

ProjectIndices::ProjectIndices(QWidget *parent)
	: QDialog(parent)
{
	setupUi(this);
}

ProjectIndices::~ProjectIndices()
{
}
