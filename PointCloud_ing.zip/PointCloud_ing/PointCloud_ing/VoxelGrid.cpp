#include "VoxelGrid.h"

VoxelGrid::VoxelGrid(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
	connect(ui.btn_OK, &QPushButton::clicked, this, &VoxelGrid::SendSignal);
}

VoxelGrid::~VoxelGrid()
{
}
void VoxelGrid::SendSignal()
{
	emit SendData(ui.lineEdit_x->text().toDouble(),ui.lineEdit_y->text().toDouble(),ui.lineEdit_z->text().toDouble());
	this->close();
}