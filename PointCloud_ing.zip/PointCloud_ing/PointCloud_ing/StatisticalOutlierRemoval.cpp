#include "StatisticalOutlierRemoval.h"

StatisticalOutlierRemoval::StatisticalOutlierRemoval(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
	//���ü�����
	ui.lineEdit_K->setValidator(new QIntValidator(1, 1024, this));
	ui.lineEdit_threshold->setValidator(new QDoubleValidator(0.1, 3.0, 3, this));
	connect(ui.btn_OK, &QPushButton::released, this, &StatisticalOutlierRemoval::SendSignal);
}

StatisticalOutlierRemoval::~StatisticalOutlierRemoval()
{
}
void StatisticalOutlierRemoval::SendSignal()
{
	emit SendData(ui.lineEdit_K->text().toInt(),ui.lineEdit_threshold->text().toDouble());
	this->close();
}