#pragma once

#include <QDialog>
#include "ui_StatisticalOutlierRemoval.h"

class StatisticalOutlierRemoval : public QDialog
{
	Q_OBJECT

public:
	StatisticalOutlierRemoval(QWidget *parent = Q_NULLPTR);
	~StatisticalOutlierRemoval();

	public slots:
	void SendSignal();
signals:
	void SendData(int ,double);

private:
	Ui::StatisticalOutlierRemoval ui;
};
