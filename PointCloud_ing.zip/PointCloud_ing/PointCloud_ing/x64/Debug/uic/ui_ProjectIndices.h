/********************************************************************************
** Form generated from reading UI file 'ProjectIndices.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROJECTINDICES_H
#define UI_PROJECTINDICES_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_ProjectIndices
{
public:

    void setupUi(QDialog *ProjectIndices)
    {
        if (ProjectIndices->objectName().isEmpty())
            ProjectIndices->setObjectName(QStringLiteral("ProjectIndices"));
        ProjectIndices->resize(400, 300);

        retranslateUi(ProjectIndices);

        QMetaObject::connectSlotsByName(ProjectIndices);
    } // setupUi

    void retranslateUi(QDialog *ProjectIndices)
    {
        ProjectIndices->setWindowTitle(QApplication::translate("ProjectIndices", "ProjectIndices", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ProjectIndices: public Ui_ProjectIndices {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROJECTINDICES_H
