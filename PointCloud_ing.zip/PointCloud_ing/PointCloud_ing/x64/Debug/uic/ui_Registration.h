/********************************************************************************
** Form generated from reading UI file 'Registration.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTRATION_H
#define UI_REGISTRATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Registration
{
public:
    QGridLayout *gridLayout;
    QComboBox *box_Source;
    QComboBox *box_Target;
    QLabel *label_3;
    QSpinBox *sbox_MaxIter;
    QLabel *label_4;
    QLineEdit *txt_CorrDis;
    QLabel *label_5;
    QLineEdit *txt_Tran;
    QLabel *label_6;
    QLineEdit *txt_Euclidean;
    QPushButton *btn_Cancel;
    QLabel *label;
    QLabel *label_2;
    QPushButton *btn_Align;

    void setupUi(QWidget *Registration)
    {
        if (Registration->objectName().isEmpty())
            Registration->setObjectName(QStringLiteral("Registration"));
        Registration->resize(352, 326);
        gridLayout = new QGridLayout(Registration);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        box_Source = new QComboBox(Registration);
        box_Source->setObjectName(QStringLiteral("box_Source"));
        box_Source->setEditable(false);

        gridLayout->addWidget(box_Source, 0, 2, 1, 1);

        box_Target = new QComboBox(Registration);
        box_Target->setObjectName(QStringLiteral("box_Target"));

        gridLayout->addWidget(box_Target, 1, 2, 1, 1);

        label_3 = new QLabel(Registration);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_3, 2, 0, 1, 2);

        sbox_MaxIter = new QSpinBox(Registration);
        sbox_MaxIter->setObjectName(QStringLiteral("sbox_MaxIter"));
        sbox_MaxIter->setMinimum(1);
        sbox_MaxIter->setMaximum(1000);

        gridLayout->addWidget(sbox_MaxIter, 2, 2, 1, 1);

        label_4 = new QLabel(Registration);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 3, 0, 1, 2);

        txt_CorrDis = new QLineEdit(Registration);
        txt_CorrDis->setObjectName(QStringLiteral("txt_CorrDis"));

        gridLayout->addWidget(txt_CorrDis, 3, 2, 1, 1);

        label_5 = new QLabel(Registration);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 4, 0, 1, 2);

        txt_Tran = new QLineEdit(Registration);
        txt_Tran->setObjectName(QStringLiteral("txt_Tran"));

        gridLayout->addWidget(txt_Tran, 4, 2, 1, 1);

        label_6 = new QLabel(Registration);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_6, 5, 0, 1, 2);

        txt_Euclidean = new QLineEdit(Registration);
        txt_Euclidean->setObjectName(QStringLiteral("txt_Euclidean"));

        gridLayout->addWidget(txt_Euclidean, 5, 2, 1, 1);

        btn_Cancel = new QPushButton(Registration);
        btn_Cancel->setObjectName(QStringLiteral("btn_Cancel"));

        gridLayout->addWidget(btn_Cancel, 6, 2, 1, 1);

        label = new QLabel(Registration);
        label->setObjectName(QStringLiteral("label"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 0, 1, 2);

        label_2 = new QLabel(Registration);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 1, 0, 1, 2);

        btn_Align = new QPushButton(Registration);
        btn_Align->setObjectName(QStringLiteral("btn_Align"));

        gridLayout->addWidget(btn_Align, 6, 1, 1, 1);


        retranslateUi(Registration);

        QMetaObject::connectSlotsByName(Registration);
    } // setupUi

    void retranslateUi(QWidget *Registration)
    {
        Registration->setWindowTitle(QApplication::translate("Registration", "Registration", Q_NULLPTR));
        label_3->setText(QApplication::translate("Registration", "MaximumIterations", Q_NULLPTR));
        label_4->setText(QApplication::translate("Registration", "MaxCorrespondenceDistance", Q_NULLPTR));
        label_5->setText(QApplication::translate("Registration", "TransformationEpsilon", Q_NULLPTR));
        label_6->setText(QApplication::translate("Registration", "EuclideanFitnessEpsilon", Q_NULLPTR));
        btn_Cancel->setText(QApplication::translate("Registration", "Cancel", Q_NULLPTR));
        label->setText(QApplication::translate("Registration", "Source", Q_NULLPTR));
        label_2->setText(QApplication::translate("Registration", "Target", Q_NULLPTR));
        btn_Align->setText(QApplication::translate("Registration", "Align", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Registration: public Ui_Registration {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTRATION_H
