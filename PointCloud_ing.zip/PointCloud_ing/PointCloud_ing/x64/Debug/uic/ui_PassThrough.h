/********************************************************************************
** Form generated from reading UI file 'PassThrough.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PASSTHROUGH_H
#define UI_PASSTHROUGH_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_PassThrough
{
public:
    QLabel *label_FieldName;
    QLabel *label_Limits;
    QLabel *label_LimitsNegative;
    QComboBox *comboBox_FieldName;
    QLineEdit *lineEdit_min;
    QLabel *label_;
    QLineEdit *lineEdit_max;
    QComboBox *comboBox_LimitsNagative;
    QPushButton *btn_OK;

    void setupUi(QDialog *PassThrough)
    {
        if (PassThrough->objectName().isEmpty())
            PassThrough->setObjectName(QStringLiteral("PassThrough"));
        PassThrough->resize(347, 280);
        label_FieldName = new QLabel(PassThrough);
        label_FieldName->setObjectName(QStringLiteral("label_FieldName"));
        label_FieldName->setGeometry(QRect(60, 30, 72, 15));
        label_Limits = new QLabel(PassThrough);
        label_Limits->setObjectName(QStringLiteral("label_Limits"));
        label_Limits->setGeometry(QRect(60, 80, 72, 15));
        label_LimitsNegative = new QLabel(PassThrough);
        label_LimitsNegative->setObjectName(QStringLiteral("label_LimitsNegative"));
        label_LimitsNegative->setGeometry(QRect(40, 130, 121, 16));
        comboBox_FieldName = new QComboBox(PassThrough);
        comboBox_FieldName->setObjectName(QStringLiteral("comboBox_FieldName"));
        comboBox_FieldName->setGeometry(QRect(180, 30, 87, 22));
        lineEdit_min = new QLineEdit(PassThrough);
        lineEdit_min->setObjectName(QStringLiteral("lineEdit_min"));
        lineEdit_min->setGeometry(QRect(140, 80, 61, 21));
        label_ = new QLabel(PassThrough);
        label_->setObjectName(QStringLiteral("label_"));
        label_->setGeometry(QRect(210, 80, 21, 16));
        lineEdit_max = new QLineEdit(PassThrough);
        lineEdit_max->setObjectName(QStringLiteral("lineEdit_max"));
        lineEdit_max->setGeometry(QRect(230, 80, 61, 21));
        comboBox_LimitsNagative = new QComboBox(PassThrough);
        comboBox_LimitsNagative->setObjectName(QStringLiteral("comboBox_LimitsNagative"));
        comboBox_LimitsNagative->setGeometry(QRect(190, 130, 87, 22));
        btn_OK = new QPushButton(PassThrough);
        btn_OK->setObjectName(QStringLiteral("btn_OK"));
        btn_OK->setGeometry(QRect(110, 200, 93, 28));

        retranslateUi(PassThrough);

        QMetaObject::connectSlotsByName(PassThrough);
    } // setupUi

    void retranslateUi(QDialog *PassThrough)
    {
        PassThrough->setWindowTitle(QApplication::translate("PassThrough", "PassThrough", Q_NULLPTR));
        label_FieldName->setText(QApplication::translate("PassThrough", "FieldName", Q_NULLPTR));
        label_Limits->setText(QApplication::translate("PassThrough", "Limits", Q_NULLPTR));
        label_LimitsNegative->setText(QApplication::translate("PassThrough", "LimitsNegative", Q_NULLPTR));
        comboBox_FieldName->clear();
        comboBox_FieldName->insertItems(0, QStringList()
         << QApplication::translate("PassThrough", "x", Q_NULLPTR)
         << QApplication::translate("PassThrough", "y", Q_NULLPTR)
         << QApplication::translate("PassThrough", "z", Q_NULLPTR)
        );
        label_->setText(QApplication::translate("PassThrough", "-", Q_NULLPTR));
        comboBox_LimitsNagative->clear();
        comboBox_LimitsNagative->insertItems(0, QStringList()
         << QApplication::translate("PassThrough", "true", Q_NULLPTR)
         << QApplication::translate("PassThrough", "false", Q_NULLPTR)
        );
        btn_OK->setText(QApplication::translate("PassThrough", "OK", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class PassThrough: public Ui_PassThrough {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PASSTHROUGH_H
