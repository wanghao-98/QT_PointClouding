/********************************************************************************
** Form generated from reading UI file 'VoxelGrid.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VOXELGRID_H
#define UI_VOXELGRID_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_VoxelGrid
{
public:
    QLabel *label_LesfSize;
    QLineEdit *lineEdit_x;
    QLineEdit *lineEdit_y;
    QLineEdit *lineEdit_z;
    QPushButton *btn_OK;

    void setupUi(QDialog *VoxelGrid)
    {
        if (VoxelGrid->objectName().isEmpty())
            VoxelGrid->setObjectName(QStringLiteral("VoxelGrid"));
        VoxelGrid->resize(411, 302);
        label_LesfSize = new QLabel(VoxelGrid);
        label_LesfSize->setObjectName(QStringLiteral("label_LesfSize"));
        label_LesfSize->setGeometry(QRect(70, 40, 72, 15));
        lineEdit_x = new QLineEdit(VoxelGrid);
        lineEdit_x->setObjectName(QStringLiteral("lineEdit_x"));
        lineEdit_x->setGeometry(QRect(180, 40, 113, 21));
        lineEdit_y = new QLineEdit(VoxelGrid);
        lineEdit_y->setObjectName(QStringLiteral("lineEdit_y"));
        lineEdit_y->setGeometry(QRect(180, 80, 113, 21));
        lineEdit_z = new QLineEdit(VoxelGrid);
        lineEdit_z->setObjectName(QStringLiteral("lineEdit_z"));
        lineEdit_z->setGeometry(QRect(180, 120, 113, 21));
        btn_OK = new QPushButton(VoxelGrid);
        btn_OK->setObjectName(QStringLiteral("btn_OK"));
        btn_OK->setGeometry(QRect(160, 210, 93, 28));

        retranslateUi(VoxelGrid);

        QMetaObject::connectSlotsByName(VoxelGrid);
    } // setupUi

    void retranslateUi(QDialog *VoxelGrid)
    {
        VoxelGrid->setWindowTitle(QApplication::translate("VoxelGrid", "VoxelGrid", Q_NULLPTR));
        label_LesfSize->setText(QApplication::translate("VoxelGrid", "LeafSize", Q_NULLPTR));
        btn_OK->setText(QApplication::translate("VoxelGrid", "OK", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class VoxelGrid: public Ui_VoxelGrid {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VOXELGRID_H
