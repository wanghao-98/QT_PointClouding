/********************************************************************************
** Form generated from reading UI file 'PointCloud_ing.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_POINTCLOUD_ING_H
#define UI_POINTCLOUD_ING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "QVTKWidget.h"

QT_BEGIN_NAMESPACE

class Ui_PointCloud_ingClass
{
public:
    QGridLayout *gridLayout_3;
    QPushButton *btn_save;
    QPushButton *btn_load;
    QPushButton *btn_random;
    QDockWidget *dockWidget_2;
    QWidget *dockWidgetContents_2;
    QHBoxLayout *horizontalLayout_2;
    QVTKWidget *qvtkWidget;
    QPushButton *btn_normals;
    QDockWidget *dockWidget;
    QWidget *dockWidgetContents;
    QHBoxLayout *horizontalLayout;
    QTreeWidget *treeWidget;
    QDockWidget *dockWidget_3;
    QWidget *dockWidgetContents_3;
    QHBoxLayout *horizontalLayout_3;
    QTreeView *treeView;
    QPushButton *btn_registration;
    QPushButton *btn_sor;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout;
    QLabel *label_R;
    QSlider *hs_R;
    QLineEdit *lineEdit_R;
    QLabel *label_G;
    QSlider *hs_G;
    QLineEdit *lineEdit_G;
    QLabel *label_B;
    QSlider *hs_B;
    QLineEdit *lineEdit_B;
    QLabel *label_Size;
    QSlider *hs_pointSize;
    QLineEdit *lineEdit_Size;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout;
    QCheckBox *checkBox_Line;
    QCheckBox *checkBox_Sphere;
    QCheckBox *checkBox_Plane;
    QCheckBox *checkBox_Cone;
    QCheckBox *checkBox_Arrow;
    QCheckBox *checkBox_Text;
    QWidget *tab_3;
    QPushButton *btn_PassThrough;
    QPushButton *btn_voxelgrid;
    QPushButton *btn_statisticaloutlierremoval;
    QWidget *tab_4;
    QPushButton *btn_greedy;
    QPushButton *btn_delete;
    QDockWidget *dockWidget_4;
    QWidget *dockWidgetContents_4;
    QGridLayout *gridLayout_2;
    QTextEdit *textEdit_test;
    QPushButton *btn_background;
    QPushButton *btn_cloudColor;
    QProgressBar *progressBar;

    void setupUi(QWidget *PointCloud_ingClass)
    {
        if (PointCloud_ingClass->objectName().isEmpty())
            PointCloud_ingClass->setObjectName(QStringLiteral("PointCloud_ingClass"));
        PointCloud_ingClass->resize(1065, 805);
        gridLayout_3 = new QGridLayout(PointCloud_ingClass);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        btn_save = new QPushButton(PointCloud_ingClass);
        btn_save->setObjectName(QStringLiteral("btn_save"));

        gridLayout_3->addWidget(btn_save, 1, 1, 1, 1);

        btn_load = new QPushButton(PointCloud_ingClass);
        btn_load->setObjectName(QStringLiteral("btn_load"));

        gridLayout_3->addWidget(btn_load, 1, 0, 1, 1);

        btn_random = new QPushButton(PointCloud_ingClass);
        btn_random->setObjectName(QStringLiteral("btn_random"));

        gridLayout_3->addWidget(btn_random, 1, 3, 1, 1);

        dockWidget_2 = new QDockWidget(PointCloud_ingClass);
        dockWidget_2->setObjectName(QStringLiteral("dockWidget_2"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(dockWidget_2->sizePolicy().hasHeightForWidth());
        dockWidget_2->setSizePolicy(sizePolicy);
        dockWidget_2->setAllowedAreas(Qt::AllDockWidgetAreas);
        dockWidgetContents_2 = new QWidget();
        dockWidgetContents_2->setObjectName(QStringLiteral("dockWidgetContents_2"));
        horizontalLayout_2 = new QHBoxLayout(dockWidgetContents_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        qvtkWidget = new QVTKWidget(dockWidgetContents_2);
        qvtkWidget->setObjectName(QStringLiteral("qvtkWidget"));
        sizePolicy.setHeightForWidth(qvtkWidget->sizePolicy().hasHeightForWidth());
        qvtkWidget->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(qvtkWidget);

        dockWidget_2->setWidget(dockWidgetContents_2);

        gridLayout_3->addWidget(dockWidget_2, 3, 0, 4, 7);

        btn_normals = new QPushButton(PointCloud_ingClass);
        btn_normals->setObjectName(QStringLiteral("btn_normals"));

        gridLayout_3->addWidget(btn_normals, 1, 6, 1, 1);

        dockWidget = new QDockWidget(PointCloud_ingClass);
        dockWidget->setObjectName(QStringLiteral("dockWidget"));
        QFont font;
        font.setFamily(QString::fromUtf8("\345\256\213\344\275\223"));
        dockWidget->setFont(font);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QStringLiteral("dockWidgetContents"));
        horizontalLayout = new QHBoxLayout(dockWidgetContents);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        treeWidget = new QTreeWidget(dockWidgetContents);
        treeWidget->headerItem()->setText(0, QString());
        treeWidget->setObjectName(QStringLiteral("treeWidget"));
        treeWidget->setFont(font);
        treeWidget->header()->setVisible(false);

        horizontalLayout->addWidget(treeWidget);

        dockWidget->setWidget(dockWidgetContents);

        gridLayout_3->addWidget(dockWidget, 1, 9, 3, 1);

        dockWidget_3 = new QDockWidget(PointCloud_ingClass);
        dockWidget_3->setObjectName(QStringLiteral("dockWidget_3"));
        dockWidgetContents_3 = new QWidget();
        dockWidgetContents_3->setObjectName(QStringLiteral("dockWidgetContents_3"));
        horizontalLayout_3 = new QHBoxLayout(dockWidgetContents_3);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        treeView = new QTreeView(dockWidgetContents_3);
        treeView->setObjectName(QStringLiteral("treeView"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\346\245\267\344\275\223"));
        treeView->setFont(font1);

        horizontalLayout_3->addWidget(treeView);

        dockWidget_3->setWidget(dockWidgetContents_3);

        gridLayout_3->addWidget(dockWidget_3, 4, 9, 1, 1);

        btn_registration = new QPushButton(PointCloud_ingClass);
        btn_registration->setObjectName(QStringLiteral("btn_registration"));

        gridLayout_3->addWidget(btn_registration, 1, 4, 1, 1);

        btn_sor = new QPushButton(PointCloud_ingClass);
        btn_sor->setObjectName(QStringLiteral("btn_sor"));

        gridLayout_3->addWidget(btn_sor, 2, 1, 1, 1);

        tabWidget = new QTabWidget(PointCloud_ingClass);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(tabWidget->sizePolicy().hasHeightForWidth());
        tabWidget->setSizePolicy(sizePolicy1);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        gridLayout = new QGridLayout(tab);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_R = new QLabel(tab);
        label_R->setObjectName(QStringLiteral("label_R"));

        gridLayout->addWidget(label_R, 0, 0, 1, 1);

        hs_R = new QSlider(tab);
        hs_R->setObjectName(QStringLiteral("hs_R"));
        hs_R->setMaximum(255);
        hs_R->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(hs_R, 0, 1, 1, 1);

        lineEdit_R = new QLineEdit(tab);
        lineEdit_R->setObjectName(QStringLiteral("lineEdit_R"));
        QSizePolicy sizePolicy2(QSizePolicy::Ignored, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(lineEdit_R->sizePolicy().hasHeightForWidth());
        lineEdit_R->setSizePolicy(sizePolicy2);

        gridLayout->addWidget(lineEdit_R, 0, 2, 1, 1);

        label_G = new QLabel(tab);
        label_G->setObjectName(QStringLiteral("label_G"));

        gridLayout->addWidget(label_G, 1, 0, 1, 1);

        hs_G = new QSlider(tab);
        hs_G->setObjectName(QStringLiteral("hs_G"));
        hs_G->setMaximum(255);
        hs_G->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(hs_G, 1, 1, 1, 1);

        lineEdit_G = new QLineEdit(tab);
        lineEdit_G->setObjectName(QStringLiteral("lineEdit_G"));
        sizePolicy2.setHeightForWidth(lineEdit_G->sizePolicy().hasHeightForWidth());
        lineEdit_G->setSizePolicy(sizePolicy2);

        gridLayout->addWidget(lineEdit_G, 1, 2, 1, 1);

        label_B = new QLabel(tab);
        label_B->setObjectName(QStringLiteral("label_B"));

        gridLayout->addWidget(label_B, 2, 0, 1, 1);

        hs_B = new QSlider(tab);
        hs_B->setObjectName(QStringLiteral("hs_B"));
        hs_B->setMaximum(255);
        hs_B->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(hs_B, 2, 1, 1, 1);

        lineEdit_B = new QLineEdit(tab);
        lineEdit_B->setObjectName(QStringLiteral("lineEdit_B"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(lineEdit_B->sizePolicy().hasHeightForWidth());
        lineEdit_B->setSizePolicy(sizePolicy3);

        gridLayout->addWidget(lineEdit_B, 2, 2, 1, 1);

        label_Size = new QLabel(tab);
        label_Size->setObjectName(QStringLiteral("label_Size"));

        gridLayout->addWidget(label_Size, 3, 0, 1, 1);

        hs_pointSize = new QSlider(tab);
        hs_pointSize->setObjectName(QStringLiteral("hs_pointSize"));
        hs_pointSize->setMinimum(1);
        hs_pointSize->setMaximum(10);
        hs_pointSize->setValue(1);
        hs_pointSize->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(hs_pointSize, 3, 1, 1, 1);

        lineEdit_Size = new QLineEdit(tab);
        lineEdit_Size->setObjectName(QStringLiteral("lineEdit_Size"));
        sizePolicy3.setHeightForWidth(lineEdit_Size->sizePolicy().hasHeightForWidth());
        lineEdit_Size->setSizePolicy(sizePolicy3);

        gridLayout->addWidget(lineEdit_Size, 3, 2, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout = new QVBoxLayout(tab_2);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        checkBox_Line = new QCheckBox(tab_2);
        checkBox_Line->setObjectName(QStringLiteral("checkBox_Line"));

        verticalLayout->addWidget(checkBox_Line);

        checkBox_Sphere = new QCheckBox(tab_2);
        checkBox_Sphere->setObjectName(QStringLiteral("checkBox_Sphere"));

        verticalLayout->addWidget(checkBox_Sphere);

        checkBox_Plane = new QCheckBox(tab_2);
        checkBox_Plane->setObjectName(QStringLiteral("checkBox_Plane"));

        verticalLayout->addWidget(checkBox_Plane);

        checkBox_Cone = new QCheckBox(tab_2);
        checkBox_Cone->setObjectName(QStringLiteral("checkBox_Cone"));

        verticalLayout->addWidget(checkBox_Cone);

        checkBox_Arrow = new QCheckBox(tab_2);
        checkBox_Arrow->setObjectName(QStringLiteral("checkBox_Arrow"));

        verticalLayout->addWidget(checkBox_Arrow);

        checkBox_Text = new QCheckBox(tab_2);
        checkBox_Text->setObjectName(QStringLiteral("checkBox_Text"));

        verticalLayout->addWidget(checkBox_Text);

        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        btn_PassThrough = new QPushButton(tab_3);
        btn_PassThrough->setObjectName(QStringLiteral("btn_PassThrough"));
        btn_PassThrough->setGeometry(QRect(20, 10, 101, 28));
        btn_voxelgrid = new QPushButton(tab_3);
        btn_voxelgrid->setObjectName(QStringLiteral("btn_voxelgrid"));
        btn_voxelgrid->setGeometry(QRect(20, 50, 93, 28));
        btn_statisticaloutlierremoval = new QPushButton(tab_3);
        btn_statisticaloutlierremoval->setObjectName(QStringLiteral("btn_statisticaloutlierremoval"));
        btn_statisticaloutlierremoval->setGeometry(QRect(20, 90, 221, 28));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        btn_greedy = new QPushButton(tab_4);
        btn_greedy->setObjectName(QStringLiteral("btn_greedy"));
        btn_greedy->setGeometry(QRect(20, 20, 161, 28));
        tabWidget->addTab(tab_4, QString());

        gridLayout_3->addWidget(tabWidget, 6, 9, 1, 1);

        btn_delete = new QPushButton(PointCloud_ingClass);
        btn_delete->setObjectName(QStringLiteral("btn_delete"));

        gridLayout_3->addWidget(btn_delete, 1, 2, 1, 1);

        dockWidget_4 = new QDockWidget(PointCloud_ingClass);
        dockWidget_4->setObjectName(QStringLiteral("dockWidget_4"));
        dockWidgetContents_4 = new QWidget();
        dockWidgetContents_4->setObjectName(QStringLiteral("dockWidgetContents_4"));
        gridLayout_2 = new QGridLayout(dockWidgetContents_4);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        textEdit_test = new QTextEdit(dockWidgetContents_4);
        textEdit_test->setObjectName(QStringLiteral("textEdit_test"));
        textEdit_test->setReadOnly(true);

        gridLayout_2->addWidget(textEdit_test, 0, 0, 1, 1);

        dockWidget_4->setWidget(dockWidgetContents_4);

        gridLayout_3->addWidget(dockWidget_4, 8, 0, 1, 10);

        btn_background = new QPushButton(PointCloud_ingClass);
        btn_background->setObjectName(QStringLiteral("btn_background"));

        gridLayout_3->addWidget(btn_background, 1, 5, 1, 1);

        btn_cloudColor = new QPushButton(PointCloud_ingClass);
        btn_cloudColor->setObjectName(QStringLiteral("btn_cloudColor"));

        gridLayout_3->addWidget(btn_cloudColor, 2, 0, 1, 1);

        progressBar = new QProgressBar(PointCloud_ingClass);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setValue(0);

        gridLayout_3->addWidget(progressBar, 5, 9, 1, 1);


        retranslateUi(PointCloud_ingClass);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(PointCloud_ingClass);
    } // setupUi

    void retranslateUi(QWidget *PointCloud_ingClass)
    {
        PointCloud_ingClass->setWindowTitle(QApplication::translate("PointCloud_ingClass", "PointCloud", Q_NULLPTR));
        btn_save->setText(QApplication::translate("PointCloud_ingClass", "\344\277\235\345\255\230\347\202\271\344\272\221", Q_NULLPTR));
        btn_load->setText(QApplication::translate("PointCloud_ingClass", "\345\212\240\350\275\275\347\202\271\344\272\221", Q_NULLPTR));
        btn_random->setText(QApplication::translate("PointCloud_ingClass", "\351\232\217\346\234\272\351\242\234\350\211\262", Q_NULLPTR));
        dockWidget_2->setWindowTitle(QApplication::translate("PointCloud_ingClass", "\347\202\271\344\272\221\345\217\257\350\247\206\345\214\226", Q_NULLPTR));
        btn_normals->setText(QApplication::translate("PointCloud_ingClass", "\346\230\276\347\244\272\346\263\225\347\272\277", Q_NULLPTR));
        dockWidget->setWindowTitle(QApplication::translate("PointCloud_ingClass", "\347\202\271\344\272\221\346\225\260\346\215\256", Q_NULLPTR));
        dockWidget_3->setWindowTitle(QApplication::translate("PointCloud_ingClass", "\345\261\236\346\200\247", Q_NULLPTR));
        btn_registration->setText(QApplication::translate("PointCloud_ingClass", "ICP\351\205\215\345\207\206", Q_NULLPTR));
        btn_sor->setText(QApplication::translate("PointCloud_ingClass", "SOR", Q_NULLPTR));
        label_R->setText(QApplication::translate("PointCloud_ingClass", "R", Q_NULLPTR));
        lineEdit_R->setText(QString());
        label_G->setText(QApplication::translate("PointCloud_ingClass", "G", Q_NULLPTR));
        label_B->setText(QApplication::translate("PointCloud_ingClass", "B", Q_NULLPTR));
        label_Size->setText(QApplication::translate("PointCloud_ingClass", "Size", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("PointCloud_ingClass", "\351\242\234\350\211\262", Q_NULLPTR));
        checkBox_Line->setText(QApplication::translate("PointCloud_ingClass", "Line", Q_NULLPTR));
        checkBox_Sphere->setText(QApplication::translate("PointCloud_ingClass", "Sphere", Q_NULLPTR));
        checkBox_Plane->setText(QApplication::translate("PointCloud_ingClass", "Plane", Q_NULLPTR));
        checkBox_Cone->setText(QApplication::translate("PointCloud_ingClass", "Cone", Q_NULLPTR));
        checkBox_Arrow->setText(QApplication::translate("PointCloud_ingClass", "Arrow", Q_NULLPTR));
        checkBox_Text->setText(QApplication::translate("PointCloud_ingClass", "Text", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("PointCloud_ingClass", "\347\273\230\345\210\266\345\275\242\347\212\266", Q_NULLPTR));
        btn_PassThrough->setText(QApplication::translate("PointCloud_ingClass", "PassThrough", Q_NULLPTR));
        btn_voxelgrid->setText(QApplication::translate("PointCloud_ingClass", "VoxelGrid", Q_NULLPTR));
        btn_statisticaloutlierremoval->setText(QApplication::translate("PointCloud_ingClass", "StatisticalOutilerRemoval", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("PointCloud_ingClass", "\346\273\244\346\263\242", Q_NULLPTR));
        btn_greedy->setText(QApplication::translate("PointCloud_ingClass", "GreedyProjection", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("PointCloud_ingClass", "\344\270\211\347\273\264\345\273\272\346\250\241", Q_NULLPTR));
        btn_delete->setText(QApplication::translate("PointCloud_ingClass", "\345\210\240\351\231\244\347\202\271\344\272\221", Q_NULLPTR));
        dockWidget_4->setWindowTitle(QApplication::translate("PointCloud_ingClass", "\346\216\247\345\210\266\345\217\260\346\266\210\346\201\257", Q_NULLPTR));
        btn_background->setText(QApplication::translate("PointCloud_ingClass", "\350\203\214\346\231\257\351\242\234\350\211\262", Q_NULLPTR));
        btn_cloudColor->setText(QApplication::translate("PointCloud_ingClass", "\347\202\271\344\272\221\351\242\234\350\211\262", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class PointCloud_ingClass: public Ui_PointCloud_ingClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_POINTCLOUD_ING_H
