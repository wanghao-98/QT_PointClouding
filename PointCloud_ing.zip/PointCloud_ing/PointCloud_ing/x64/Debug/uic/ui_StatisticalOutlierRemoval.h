/********************************************************************************
** Form generated from reading UI file 'StatisticalOutlierRemoval.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTICALOUTLIERREMOVAL_H
#define UI_STATISTICALOUTLIERREMOVAL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_StatisticalOutlierRemoval
{
public:
    QLabel *label_K;
    QLabel *label_threshold;
    QLineEdit *lineEdit_K;
    QLineEdit *lineEdit_threshold;
    QPushButton *btn_OK;

    void setupUi(QDialog *StatisticalOutlierRemoval)
    {
        if (StatisticalOutlierRemoval->objectName().isEmpty())
            StatisticalOutlierRemoval->setObjectName(QStringLiteral("StatisticalOutlierRemoval"));
        StatisticalOutlierRemoval->resize(400, 300);
        label_K = new QLabel(StatisticalOutlierRemoval);
        label_K->setObjectName(QStringLiteral("label_K"));
        label_K->setGeometry(QRect(100, 70, 21, 16));
        label_threshold = new QLabel(StatisticalOutlierRemoval);
        label_threshold->setObjectName(QStringLiteral("label_threshold"));
        label_threshold->setGeometry(QRect(90, 140, 72, 15));
        lineEdit_K = new QLineEdit(StatisticalOutlierRemoval);
        lineEdit_K->setObjectName(QStringLiteral("lineEdit_K"));
        lineEdit_K->setGeometry(QRect(190, 70, 113, 21));
        lineEdit_threshold = new QLineEdit(StatisticalOutlierRemoval);
        lineEdit_threshold->setObjectName(QStringLiteral("lineEdit_threshold"));
        lineEdit_threshold->setGeometry(QRect(190, 140, 113, 21));
        btn_OK = new QPushButton(StatisticalOutlierRemoval);
        btn_OK->setObjectName(QStringLiteral("btn_OK"));
        btn_OK->setGeometry(QRect(150, 200, 93, 28));

        retranslateUi(StatisticalOutlierRemoval);

        QMetaObject::connectSlotsByName(StatisticalOutlierRemoval);
    } // setupUi

    void retranslateUi(QDialog *StatisticalOutlierRemoval)
    {
        StatisticalOutlierRemoval->setWindowTitle(QApplication::translate("StatisticalOutlierRemoval", "StatisticalOutlierRemoval", Q_NULLPTR));
        label_K->setText(QApplication::translate("StatisticalOutlierRemoval", "K", Q_NULLPTR));
        label_threshold->setText(QApplication::translate("StatisticalOutlierRemoval", "Threshold", Q_NULLPTR));
        btn_OK->setText(QApplication::translate("StatisticalOutlierRemoval", "OK", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class StatisticalOutlierRemoval: public Ui_StatisticalOutlierRemoval {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTICALOUTLIERREMOVAL_H
