/****************************************************************************
** Meta object code from reading C++ file 'PointCloud_ing.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../PointCloud_ing.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'PointCloud_ing.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PointCloud_ing_t {
    QByteArrayData data[40];
    char stringdata0[557];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PointCloud_ing_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PointCloud_ing_t qt_meta_stringdata_PointCloud_ing = {
    {
QT_MOC_LITERAL(0, 0, 14), // "PointCloud_ing"
QT_MOC_LITERAL(1, 15, 11), // "RandomColor"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 12), // "RValueChange"
QT_MOC_LITERAL(4, 41, 5), // "value"
QT_MOC_LITERAL(5, 47, 12), // "GValueChange"
QT_MOC_LITERAL(6, 60, 12), // "BValueChange"
QT_MOC_LITERAL(7, 73, 15), // "RLineEditChange"
QT_MOC_LITERAL(8, 89, 15), // "GLineEditChange"
QT_MOC_LITERAL(9, 105, 15), // "BLineEditChange"
QT_MOC_LITERAL(10, 121, 18), // "SizeLineEditChange"
QT_MOC_LITERAL(11, 140, 14), // "RGBValueChange"
QT_MOC_LITERAL(12, 155, 15), // "PointSizeChange"
QT_MOC_LITERAL(13, 171, 8), // "LoadFile"
QT_MOC_LITERAL(14, 180, 8), // "SaveFile"
QT_MOC_LITERAL(15, 189, 4), // "Line"
QT_MOC_LITERAL(16, 194, 5), // "state"
QT_MOC_LITERAL(17, 200, 6), // "Sphere"
QT_MOC_LITERAL(18, 207, 5), // "Plane"
QT_MOC_LITERAL(19, 213, 4), // "Cone"
QT_MOC_LITERAL(20, 218, 5), // "Arrow"
QT_MOC_LITERAL(21, 224, 8), // "Cylinder"
QT_MOC_LITERAL(22, 233, 4), // "Text"
QT_MOC_LITERAL(23, 238, 16), // "PassThrough_show"
QT_MOC_LITERAL(24, 255, 23), // "ReceiveData_PassThrough"
QT_MOC_LITERAL(25, 279, 14), // "VoxelGrid_show"
QT_MOC_LITERAL(26, 294, 21), // "ReceiveData_VoxelGrid"
QT_MOC_LITERAL(27, 316, 30), // "StatisticalOutlierRemoval_show"
QT_MOC_LITERAL(28, 347, 37), // "ReceiveData_StatisticalOutlie..."
QT_MOC_LITERAL(29, 385, 17), // "Registration_show"
QT_MOC_LITERAL(30, 403, 24), // "ReceiveData_Registration"
QT_MOC_LITERAL(31, 428, 18), // "Clicked_Background"
QT_MOC_LITERAL(32, 447, 18), // "Clicked_CloudColor"
QT_MOC_LITERAL(33, 466, 14), // "DisplayNormals"
QT_MOC_LITERAL(34, 481, 16), // "Clicked_DataBase"
QT_MOC_LITERAL(35, 498, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(36, 515, 4), // "item"
QT_MOC_LITERAL(37, 520, 6), // "column"
QT_MOC_LITERAL(38, 527, 14), // "Clicked_Delete"
QT_MOC_LITERAL(39, 542, 14) // "Clicked_Greedy"

    },
    "PointCloud_ing\0RandomColor\0\0RValueChange\0"
    "value\0GValueChange\0BValueChange\0"
    "RLineEditChange\0GLineEditChange\0"
    "BLineEditChange\0SizeLineEditChange\0"
    "RGBValueChange\0PointSizeChange\0LoadFile\0"
    "SaveFile\0Line\0state\0Sphere\0Plane\0Cone\0"
    "Arrow\0Cylinder\0Text\0PassThrough_show\0"
    "ReceiveData_PassThrough\0VoxelGrid_show\0"
    "ReceiveData_VoxelGrid\0"
    "StatisticalOutlierRemoval_show\0"
    "ReceiveData_StatisticalOutlierRemoval\0"
    "Registration_show\0ReceiveData_Registration\0"
    "Clicked_Background\0Clicked_CloudColor\0"
    "DisplayNormals\0Clicked_DataBase\0"
    "QTreeWidgetItem*\0item\0column\0"
    "Clicked_Delete\0Clicked_Greedy"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PointCloud_ing[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      33,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  179,    2, 0x0a /* Public */,
       3,    1,  180,    2, 0x0a /* Public */,
       5,    1,  183,    2, 0x0a /* Public */,
       6,    1,  186,    2, 0x0a /* Public */,
       7,    0,  189,    2, 0x0a /* Public */,
       8,    0,  190,    2, 0x0a /* Public */,
       9,    0,  191,    2, 0x0a /* Public */,
      10,    0,  192,    2, 0x0a /* Public */,
      11,    0,  193,    2, 0x0a /* Public */,
      12,    1,  194,    2, 0x0a /* Public */,
      13,    0,  197,    2, 0x0a /* Public */,
      14,    0,  198,    2, 0x0a /* Public */,
      15,    1,  199,    2, 0x0a /* Public */,
      17,    1,  202,    2, 0x0a /* Public */,
      18,    1,  205,    2, 0x0a /* Public */,
      19,    1,  208,    2, 0x0a /* Public */,
      20,    1,  211,    2, 0x0a /* Public */,
      21,    1,  214,    2, 0x0a /* Public */,
      22,    1,  217,    2, 0x0a /* Public */,
      23,    0,  220,    2, 0x0a /* Public */,
      24,    4,  221,    2, 0x0a /* Public */,
      25,    0,  230,    2, 0x0a /* Public */,
      26,    3,  231,    2, 0x0a /* Public */,
      27,    0,  238,    2, 0x0a /* Public */,
      28,    2,  239,    2, 0x0a /* Public */,
      29,    0,  244,    2, 0x0a /* Public */,
      30,    6,  245,    2, 0x0a /* Public */,
      31,    0,  258,    2, 0x0a /* Public */,
      32,    0,  259,    2, 0x0a /* Public */,
      33,    0,  260,    2, 0x0a /* Public */,
      34,    2,  261,    2, 0x0a /* Public */,
      38,    0,  266,    2, 0x0a /* Public */,
      39,    0,  267,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Double, QMetaType::Double, QMetaType::QString,    2,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Double,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Int, QMetaType::Double, QMetaType::Double, QMetaType::Double,    2,    2,    2,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 35, QMetaType::Int,   36,   37,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PointCloud_ing::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        PointCloud_ing *_t = static_cast<PointCloud_ing *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->RandomColor(); break;
        case 1: _t->RValueChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->GValueChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->BValueChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->RLineEditChange(); break;
        case 5: _t->GLineEditChange(); break;
        case 6: _t->BLineEditChange(); break;
        case 7: _t->SizeLineEditChange(); break;
        case 8: _t->RGBValueChange(); break;
        case 9: _t->PointSizeChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->LoadFile(); break;
        case 11: _t->SaveFile(); break;
        case 12: _t->Line((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->Sphere((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->Plane((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->Cone((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->Arrow((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->Cylinder((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->Text((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->PassThrough_show(); break;
        case 20: _t->ReceiveData_PassThrough((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 21: _t->VoxelGrid_show(); break;
        case 22: _t->ReceiveData_VoxelGrid((*reinterpret_cast< double(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 23: _t->StatisticalOutlierRemoval_show(); break;
        case 24: _t->ReceiveData_StatisticalOutlierRemoval((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 25: _t->Registration_show(); break;
        case 26: _t->ReceiveData_Registration((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< double(*)>(_a[4])),(*reinterpret_cast< double(*)>(_a[5])),(*reinterpret_cast< double(*)>(_a[6]))); break;
        case 27: _t->Clicked_Background(); break;
        case 28: _t->Clicked_CloudColor(); break;
        case 29: _t->DisplayNormals(); break;
        case 30: _t->Clicked_DataBase((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 31: _t->Clicked_Delete(); break;
        case 32: _t->Clicked_Greedy(); break;
        default: ;
        }
    }
}

const QMetaObject PointCloud_ing::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_PointCloud_ing.data,
      qt_meta_data_PointCloud_ing,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *PointCloud_ing::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PointCloud_ing::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PointCloud_ing.stringdata0))
        return static_cast<void*>(const_cast< PointCloud_ing*>(this));
    return QWidget::qt_metacast(_clname);
}

int PointCloud_ing::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 33)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 33;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 33)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 33;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
