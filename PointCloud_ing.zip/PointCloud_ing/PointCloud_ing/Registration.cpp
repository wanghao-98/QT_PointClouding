#include "Registration.h"

Registration::Registration(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
	connect(ui.btn_Align, &QPushButton::released, this, &Registration::SendSignal);
}

void Registration::Init(QStringList text)
{
	ui.box_Source->addItems(text);
	ui.box_Target->addItems(text);
}

void Registration::SendSignal()
{
	QString source = ui.box_Source->currentText();
	QString target = ui.box_Target->currentText();
	int MaxIter = ui.sbox_MaxIter->value();
	double CorrDis = ui.txt_CorrDis->text().toDouble();
	double Euclidean = ui.txt_Euclidean->text().toDouble();
	double Tran = ui.txt_Tran->text().toDouble();
	
	

	emit SendData(source, target, MaxIter, CorrDis, Euclidean, Tran);
	this->close();
}


Registration::~Registration()
{
}
