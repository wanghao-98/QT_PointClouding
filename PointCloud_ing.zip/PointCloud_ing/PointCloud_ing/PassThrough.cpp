#include "PassThrough.h"

PassThrough::PassThrough(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
	ui.btn_OK->setDefault(true);
	connect(ui.btn_OK, &QPushButton::released, this, &PassThrough::SendSignal);
}

PassThrough::~PassThrough()
{
}
void PassThrough::SendSignal()
{
	QString fieldname=ui.comboBox_FieldName->currentText();
	double min=ui.lineEdit_min->text().toDouble();
	double max = ui.lineEdit_max->text().toDouble();
	QString limitsnegative = ui.comboBox_LimitsNagative->currentText();

	emit SendData(fieldname,min,max,limitsnegative);
	this->close();
}

