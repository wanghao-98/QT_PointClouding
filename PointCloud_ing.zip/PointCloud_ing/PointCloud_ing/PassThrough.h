#pragma once

#include <QDialog>
#include "ui_PassThrough.h"

class PassThrough : public QDialog
{
	Q_OBJECT

public:
	PassThrough(QWidget *parent = Q_NULLPTR);
	~PassThrough();

public slots:
	void SendSignal();
signals:
	void SendData(QString ,double,double,QString );


private:
	Ui::PassThrough ui;
};
