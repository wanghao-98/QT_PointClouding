#pragma once

#include <QDialog>
#include "ui_ProjectIndices.h"

class ProjectIndices : public QDialog, public Ui::ProjectIndices
{
	Q_OBJECT

public:
	ProjectIndices(QWidget *parent = Q_NULLPTR);
	~ProjectIndices();
};
