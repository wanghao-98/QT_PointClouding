#pragma once

#include <QDialog>
#include "ui_Registration.h"

class Registration : public QDialog
{
	Q_OBJECT

public:
	Registration(QWidget *parent = Q_NULLPTR);
	void Init(QStringList text);
	~Registration();

public slots:
	void SendSignal();
signals:
	void SendData(QString, QString,int,double, double, double);

private:
	
	Ui::Registration ui;
};
