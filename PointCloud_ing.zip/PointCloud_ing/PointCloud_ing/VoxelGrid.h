#pragma once

#include <QDialog>
#include "ui_VoxelGrid.h"

class VoxelGrid : public QDialog
{
	Q_OBJECT

public:
	VoxelGrid(QWidget *parent = Q_NULLPTR);
	~VoxelGrid();
public slots:
	void SendSignal();
signals:
	void SendData(double,double,double);

private:
	Ui::VoxelGrid ui;
};
