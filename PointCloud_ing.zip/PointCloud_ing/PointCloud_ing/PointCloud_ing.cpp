﻿#include "PointCloud_ing.h"
//#include<QFileDialog>
#include<random>
#include<QCloseEvent>


PointCloud_ing::PointCloud_ing(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
	//将数据成员初始化
	cloud.second.reset(new pcl::PointCloud<PointT>);
	normals.reset(new pcl::PointCloud<pcl::Normal>);
	//创建PCLVisualizer对象，并将交互模式设为false，以便将qvtkwidget的交互方式传给PCLVisualizer
	viewer.reset(new pcl::visualization::PCLVisualizer("viewer", false));
	
	
	
	//将PCLVisaulizer的渲染关联到qvtkWidget，两者的变化是否同步？，需要进行更新
	ui.qvtkWidget->SetRenderWindow(viewer->getRenderWindow());
	//将qvtkWidget的交互方式传递给PCLVisualizer对象，包括两个参数。
	viewer->setupInteractor(ui.qvtkWidget->GetInteractor(), ui.qvtkWidget->GetRenderWindow());
	//设置背景，使用viewer，如果使用qvtkWidget对象呢？两者的操作是否同步？
	viewer->setBackgroundColor(255, 255, 255);
	viewer->resetCamera();//重设相机参数
	
	//viewer->addCoordinateSystem(0.01);
	ui.qvtkWidget->update();//更新窗口，之后的交互也需要更新。

	
	//对TreeView属性窗口进行设置，两列宽度
	ui.treeView->setColumnWidth(0, 50);
	ui.treeView->setColumnWidth(1, 200);
	//在TreeView中添加的标准模型，设置表头
	goodsModel->setHeaderData(0, Qt::Horizontal, tr("Attribute"));
	goodsModel->setHeaderData(1, Qt::Horizontal, tr("Value"));
	//将标准模型与treeView绑定
	ui.treeView->setModel(goodsModel);

	ui.treeWidget->setAcceptDrops(true);
	//setAcceptDrops(false);

	red = ui.hs_R->value();
	green = ui.hs_G->value();
	blue = ui.hs_B->value();
	ui.lineEdit_R->setText(QString::number(red));
	ui.lineEdit_G->setText(QString::number(green));
	ui.lineEdit_B->setText(QString::number(blue));
	ui.lineEdit_Size->setText(QString::number(ui.hs_pointSize->value()));

	connect(ui.lineEdit_R, SIGNAL(editingFinished()), this, SLOT(RLineEditChange()));
	connect(ui.lineEdit_G, SIGNAL(editingFinished()), this, SLOT(GLineEditChange()));
	connect(ui.lineEdit_B, &QLineEdit::editingFinished, this, &PointCloud_ing::BLineEditChange);
	connect(ui.lineEdit_Size, &QLineEdit::editingFinished, this, &PointCloud_ing::SizeLineEditChange);
	connect(ui.lineEdit_R, SIGNAL(editingFinished()), this, SLOT(RGBValueChange()));
	connect(ui.lineEdit_G, SIGNAL(editingFinished()), this, SLOT(RGBValueChange()));
	connect(ui.lineEdit_B, &QLineEdit::editingFinished, this, &PointCloud_ing::RGBValueChange);

	connect(ui.hs_R, &QSlider::valueChanged, this, &PointCloud_ing::RValueChange);
	connect(ui.hs_G, SIGNAL(valueChanged(int)), this, SLOT(GValueChange(int)));
	connect(ui.hs_B, &QSlider::valueChanged, this, &PointCloud_ing::BValueChange);
	connect(ui.hs_R, &QSlider::sliderReleased, this, &PointCloud_ing::RGBValueChange);
	connect(ui.hs_G, &QSlider::sliderReleased, this, &PointCloud_ing::RGBValueChange);
	connect(ui.hs_B, &QSlider::sliderReleased, this, &PointCloud_ing::RGBValueChange);

	connect(ui.hs_pointSize, SIGNAL(valueChanged(int)), this, SLOT(PointSizeChange(int)));
	//Slider的信号valueChange（int value）会自动将value的值传递给槽函数，信号的参数要大于等于槽函数的参数。参数会自动传递。

	//设置点云颜色
	connect(ui.btn_cloudColor, &QPushButton::released, this, &PointCloud_ing::Clicked_CloudColor);


	connect(ui.btn_load, &QPushButton::clicked, this, &PointCloud_ing::LoadFile);
	connect(ui.btn_save, SIGNAL(clicked()), this, SLOT(SaveFile()));
	connect(ui.btn_random, &QPushButton::clicked, this, &PointCloud_ing::RandomColor);
	//绘制基本形状
	connect(ui.checkBox_Line, &QCheckBox::stateChanged, this, &PointCloud_ing::Line);
	connect(ui.checkBox_Sphere, SIGNAL(stateChanged(int)), this, SLOT(Sphere(int)));
	connect(ui.checkBox_Plane, &QCheckBox::stateChanged, this, &PointCloud_ing::Plane);
	connect(ui.checkBox_Cone, SIGNAL(stateChanged(int)), this, SLOT(Cone(int)));
	connect(ui.checkBox_Arrow, &QCheckBox::stateChanged, this, &PointCloud_ing::Arrow);
	connect(ui.checkBox_Text, SIGNAL(stateChanged(int)), this, SLOT(Text(int)));
	//滤波处理
	/*1.PassThrough直通滤波*/
	connect(ui.btn_PassThrough, &QPushButton::released, this, &PointCloud_ing::PassThrough_show);
	connect(&passthrough, &PassThrough::SendData, this, &PointCloud_ing::ReceiveData_PassThrough);
	/*2.VoxelGrid体素滤波*/
	connect(ui.btn_voxelgrid, &QPushButton::released, this, &PointCloud_ing::VoxelGrid_show);
	connect(&voxelgrid, &VoxelGrid::SendData, this, &PointCloud_ing::ReceiveData_VoxelGrid);
	/*3.StatisticalOutlierRemoval统计滤波*/
	connect(ui.btn_statisticaloutlierremoval, &QPushButton::released, this, &PointCloud_ing::StatisticalOutlierRemoval_show);
	connect(&statisticaloutlierremoval, &StatisticalOutlierRemoval::SendData, this, &PointCloud_ing::ReceiveData_StatisticalOutlierRemoval);
	
	//Registration
	connect(ui.btn_registration, &QPushButton::released, this, &PointCloud_ing::Registration_show);
	connect(&registration, &Registration::SendData, this, &PointCloud_ing::ReceiveData_Registration);

	//显示法线
	connect(ui.btn_normals, &QPushButton::released, this, &PointCloud_ing::DisplayNormals);

	//删除点云
	connect(ui.btn_delete, &QPushButton::released, this, &PointCloud_ing::Clicked_Delete);

	//背景色
	connect(ui.btn_background, &QPushButton::released, this, &PointCloud_ing::Clicked_Background);

	//点击数据库中的文件时，显示属性
	connect(ui.treeWidget, &QTreeWidget::itemClicked, this, &PointCloud_ing::Clicked_DataBase);

	//点云三维建模
	connect(ui.btn_greedy, &QPushButton::released, this, &PointCloud_ing::Clicked_Greedy);

	//SOR
	connect(ui.btn_sor, &QPushButton::released, this, &PointCloud_ing::SOR);
}

void PointCloud_ing::dragEnterEvent(QDragEnterEvent *event)
{
	if (event->mimeData()->hasFormat("text/uri-list"))
	{
		event->acceptProposedAction();
	}
}

void PointCloud_ing::dropEvent(QDropEvent *event)
{
	QList<QUrl> urls = event->mimeData()->urls();
	if (urls.isEmpty())
	{
		return;
	}
	QString filename = urls.first().toLocalFile();
	if (filename.isEmpty())
	{
		return;
	}
	else
	{
		QTextCodec *code = QTextCodec::codecForName("GB2312");//解决中文路径问题
		clouds[filename].reset(new pcl::PointCloud<PointT>);
		pcl::io::loadPCDFile(code->fromUnicode(filename).data(), *clouds[filename]);
		//在treeWidget中显示打开的文件名。点云数据库
		QTreeWidgetItem *imageItem1 = new QTreeWidgetItem(ui.treeWidget, QStringList(filename));
		//控制台显示文件是否打开成功
		ui.textEdit_test->append(tr("open pcd file succeed.load ") + QString::number(clouds[filename]->size()) + " points");

		//添加成功打开的文件，并将ID设为文件名
		viewer->addPointCloud(clouds[filename], filename.toStdString());
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, filename.toStdString());
		ui.hs_pointSize->setValue(2);
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 0, 0, 0, filename.toStdString());
		viewer->resetCamera();//必须要有，重新设置相机参数
		ui.qvtkWidget->update();
	}
}


bool PointCloud_ing::okToContinue()
{
	int r = QMessageBox::warning(this, tr("PointCloud"),
		tr("Do you want to quit?"),
		QMessageBox::Yes | QMessageBox::No
		| QMessageBox::Cancel);
	if (r == QMessageBox::Yes) {
		return true;
	}
	else if (r == QMessageBox::Cancel) {
		return false;
	}
}


void PointCloud_ing::closeEvent(QCloseEvent *event)
{
	if (okToContinue())
	{
		event->accept();
	}
	else
	{
		event->ignore();
	}
}

void PointCloud_ing::SOR()
{
	sor.exec();

}


void PointCloud_ing::Clicked_CloudColor()
{
	std::shared_ptr<QColorDialog> colorDialog(new QColorDialog(this));	
	if (colorDialog->exec()==QColorDialog::Accepted)
	{
		int r, g, b, a;
		r=colorDialog->selectedColor().red();
		g = colorDialog->selectedColor().green();
		b = colorDialog->selectedColor().blue();
		viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, r/255.0, g/255.0, b/255.0, cloud.first.toStdString());
		ui.qvtkWidget->update();
	}
}

void PointCloud_ing::Clicked_Greedy()
{
	//----------------法线估计-------------------------
	pcl::NormalEstimation<PointT, Normal> n;
	pcl::PointCloud<Normal>::Ptr normals(new pcl::PointCloud<Normal>);
	pcl::search::KdTree<PointT>::Ptr tree(new pcl::search::KdTree<PointT>);
	tree->setInputCloud(cloud.second);
	n.setInputCloud(cloud.second);
	n.setSearchMethod(tree);
	n.setKSearch(20);
	n.compute(*normals);
	//-----------------连接XYZ和法向量字段--------------
	pcl::PointCloud<pcl::PointNormal>::Ptr cloud_with_normals(new pcl::PointCloud<pcl::PointNormal>);
	pcl::concatenateFields(*cloud.second, *normals, *cloud_with_normals);
	//------------------定义搜索树对象------------------------
	pcl::search::KdTree<pcl::PointNormal>::Ptr tree2(new pcl::search::KdTree<pcl::PointNormal>);
	tree2->setInputCloud(cloud_with_normals);
	//------------------贪婪投影三角化------------------
	pcl::GreedyProjectionTriangulation<pcl::PointNormal> gp3;//定义三角化对象
	pcl::PolygonMesh triangles;//存储最终三角化的网格模型
	gp3.setSearchRadius(0.015);//设置连接点之间的最大距离（即三角形的最大边长）
	gp3.setMu(2.5);//设置被样本点搜索其临近点的最远距离，为了适应点云密度的变化
	gp3.setMaximumNearestNeighbors(100);//设置样本点可搜索的邻域个数
	gp3.setMaximumSurfaceAngle(M_PI / 4); // 设置某点法线方向偏离样本点法线方向的最大角度
	gp3.setMinimumAngle(M_PI / 18); // 设置三角化后得到三角形内角的最小角度
	gp3.setMaximumAngle(2 * M_PI / 3); // 设置三角化后得到三角形内角的最大角度
	gp3.setNormalConsistency(false);//设置该参数保证法线朝向一致

									// Get result
	gp3.setInputCloud(cloud_with_normals);//设置输入点云为有向点云
	gp3.setSearchMethod(tree2);//设置搜索方式
	gp3.reconstruct(triangles);//重建提取三角化

	viewer->addPolygonMesh(triangles, "my");
	ui.qvtkWidget->update();
}

void PointCloud_ing::Clicked_Background()
{
	int r, g, b,a;
	//QColorDialog colorDialog(this);
	//if (colorDialog.exec()==QColorDialog::Accepted)
	//{
	//	r=colorDialog.selectedColor().red();
	//	g = colorDialog.selectedColor().green();
	//	b = colorDialog.selectedColor().blue();
	//	viewer->setBackgroundColor(r, g, b);
	//}
	QColor color = QColorDialog::getColor();//静态方法，无需实例化对象，其他的标准对话框也有类似的静态方法，这是最简单的使用方法
	if (color.isValid())
	{
		r = color.red();
		g = color.green();
		b = color.blue();
		viewer->setBackgroundColor(r/255.0, g/255.0, b/255.0);
	}

	
	ui.qvtkWidget->update();
}


void PointCloud_ing::DisplayNormals()
{
	pcl::NormalEstimation<PointT, pcl::Normal> ne;
	ne.setInputCloud(cloud.second);
	ne.setKSearch(32);
	//ne.setRadiusSearch(0.02);
	ne.compute(*normals);
	
	
	viewer->addPointCloudNormals<PointT, pcl::Normal>(cloud.second, normals, 10, 0.01, cloud.first.toStdString()+"normals");
	viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 1, 0, 0, cloud.first.toStdString() + "normals");
	//viewer->addPointCloudNormals<pcl::Normal>(normals, 10, 0.02, cloud.first.toStdString() + "normals");
	//viewer->updateCamera();
	ui.qvtkWidget->update();
	ui.textEdit_test->append("normals display");
}


void PointCloud_ing::Registration_show()
{
	QStringList text;
	QTreeWidgetItemIterator it(ui.treeWidget);
	while (*it)
	{
		text.append((*it)->text(0));
		++it;
	}
	registration.Init(text);
	registration.exec();
}

void PointCloud_ing::ReceiveData_Registration(QString Source, QString Target, int MaxIter, double CorrDis, double Euclidean, double Tran)
{
	pcl::PointCloud<PointT>::Ptr source(new pcl::PointCloud<PointT>);
	pcl::PointCloud<PointT>::Ptr target(new pcl::PointCloud<PointT>);
	pcl::PointCloud<PointT>::Ptr traned(new pcl::PointCloud<PointT>);

	pcl::IterativeClosestPoint<PointT, PointT> icp;
	icp.setInputSource(clouds[Source]);
	icp.setInputTarget(clouds[Target]);
	//icp.setEuclideanFitnessEpsilon(Euclidean);
	//icp.setMaxCorrespondenceDistance(CorrDis);
	//icp.setMaximumIterations(MaxIter);
	//icp.setTransformationEpsilon(Tran);
	//icp.setUseReciprocalCorrespondences(false);
	icp.align(*traned);

	if (icp.hasConverged())
	{
		cloud.first = Source + ".transformed";
		cloud.second = traned;
		viewer->addPointCloud(cloud.second, cloud.first.toStdString());

		clouds.insert(cloud);

		QTreeWidgetItem *imageItem1 = new QTreeWidgetItem(ui.treeWidget, QStringList(Source + ".transformed"));
		ui.treeWidget->setCurrentItem(imageItem1);

		ui.qvtkWidget->update();
		ui.textEdit_test->append("ICP");
		Eigen::Matrix4f tran= icp.getFinalTransformation().transpose();//矩阵是按列存储的
		std::string trans = std::to_string(tran(0)) + "\t" + std::to_string(tran(1)) + "\t"
			+std::to_string(tran(2)) + "\t" + std::to_string(icp.getFinalTransformation()(3)) + "\n" +
			std::to_string(tran(4)) + "\t" + std::to_string(tran(5)) + "\t" +
			std::to_string(tran(6)) + "\t" + std::to_string(tran(7)) + "\n" +
			std::to_string(tran(8)) + "\t" + std::to_string(tran(9)) + "\t" +
			std::to_string(tran(10)) + "\t" + std::to_string(tran(11)) + "\n" +
			std::to_string(tran(12)) + "\t" + std::to_string(tran(13)) + "\t" +
			std::to_string(tran(14)) + "\t" + std::to_string(tran(15)) + "\n";
		ui.textEdit_test->append(QString::fromStdString( trans));
	}

}




void PointCloud_ing::StatisticalOutlierRemoval_show()
{
	statisticaloutlierremoval.exec();//exec非模态对话框，不能进行其他操作
}
void PointCloud_ing::ReceiveData_StatisticalOutlierRemoval(int K, double threshold)
{
	//存储处理之后的点云数据，在方法函数内定义，包括ID和点云数据
	std::pair<QString, pcl::PointCloud<PointT>::Ptr> cloud_sor;
	//需要将点云数据进行初始化
	cloud_sor.second.reset(new pcl::PointCloud<PointT>);
	//定义统计滤波对象
	pcl::StatisticalOutlierRemoval<PointT> sor;
	sor.setInputCloud(cloud.second);
	sor.setMeanK(K);
	sor.setStddevMulThresh(threshold);
	sor.filter(*cloud_sor.second);

	if (!cloud_sor.second->empty())
	{
		//存储点云ID
		cloud_sor.first = cloud.first + "_sor";
		//将点云ID和数据存到内存中，防止销毁，直接插入到map中
		clouds.insert(cloud_sor);
		//选中文件时，会存储选择的QTreeWidgetItem，此处添加子QTreeWidgetItem，形成树结构，selectedItem为父对象
		QTreeWidgetItem *item = new QTreeWidgetItem(selectedItem, QStringList(cloud_sor.first));
		selectedItem->setExpanded(true);
		//将点云数据添加到viewer中，并设置ID
		viewer->addPointCloud(clouds[cloud_sor.first], cloud_sor.first.toStdString());
		ui.qvtkWidget->update();
		ui.textEdit_test->append(tr("SOR"));
	}

}


void PointCloud_ing::VoxelGrid_show()
{
	voxelgrid.exec();
}
void PointCloud_ing::ReceiveData_VoxelGrid(double x,double y,double z)
{
	pcl::VoxelGrid<PointT> voxel;	
	voxel.setInputCloud(cloud.second);
	voxel.setLeafSize(x, y, z);
	voxel.filter(*cloud.second);

	viewer->updatePointCloud(cloud.second);
	ui.qvtkWidget->update();
}

void PointCloud_ing::PassThrough_show()
{
	//PassThrough passthrough=new PassThrough(this);	
	passthrough.exec();
	

}
void PointCloud_ing::ReceiveData_PassThrough(QString fieldname,double min,double max,QString limitsnegative)
{
	ui.textEdit_test->append(fieldname);
	ui.textEdit_test->append(QString::number(min));
	ui.textEdit_test->append(QString::number(max));
	ui.textEdit_test->append(limitsnegative);

	//pcl::PointCloud<PointT>::Ptr cloud_filter(new pcl::PointCloud<PointT>);
	pcl::PassThrough<PointT> pass;
	pass.setInputCloud(cloud.second);
	pass.setFilterFieldName(fieldname.toStdString());
	pass.setFilterLimits(min, max);
	pass.setFilterLimitsNegative(limitsnegative == "true");
	pass.filter(*cloud.second);
	//viewer->removePointCloud("cloud");
	//viewer->addPointCloud(cloud_filter, "cloud_filter");
	viewer->updatePointCloud(cloud.second);
	ui.qvtkWidget->update();

}

//绘制基本形状函数
void PointCloud_ing::Arrow(int state)
{
	if (state==Qt::CheckState::Checked)
	{
		PointT p1;
		p1.x = 0; p1.y = 0; p1.z = 0;
		PointT p2;
		p2.x = 0.5; p2.y = 0.3; p2.z = 0.3;
		viewer->addArrow<PointT>(p1, p2,0,255,0, "arrow");
		ui.qvtkWidget->update();
	}
	else
	{
		viewer->removeShape("arrow");
		ui.qvtkWidget->update();
	}
	
}
void PointCloud_ing::Cylinder(int state)
{

}
void PointCloud_ing::Text(int state)
{
	if (state==Qt::CheckState::Checked)
	{
		PointT p1;
		p1.x = 0; p1.y = 0; p1.z = 0;
		viewer->addText("beautiful",20,30,0,255,0 ,"text");
		//viewer->addText("beautiful", 50, 50, "text");
		ui.qvtkWidget->update();
	}
	else
	{
		viewer->removeShape("text");
		ui.qvtkWidget->update();
	}
}
void PointCloud_ing::Line(int state)
{
	if (state==Qt::CheckState::Checked)
	{
		PointT p1;
		p1.x = 0; p1.y = 0; p1.z = 0;
		PointT p2;
		p2.x = 0.5; p2.y = 0.5; p2.z =0.5;
		viewer->addLine<PointT>(p1,p2, "line");
		ui.qvtkWidget->update();
	}
	else
	{
		viewer->removeShape("line");
		ui.qvtkWidget->update();
	}
	
}
void PointCloud_ing::Sphere(int state)
{
	if (state==Qt::CheckState::Checked)
	{
		PointT p;
		viewer->addSphere(p, 0.2, 255, 0, 0, "sphere");
		ui.qvtkWidget->update();
	}
	else
	{
		viewer->removeShape("sphere");
		ui.qvtkWidget->update();
	}
}
void PointCloud_ing::Plane(int state)
{
	if (state==Qt::CheckState::Checked)
	{
		pcl::ModelCoefficients coeffs;
		coeffs.values.push_back(0.0);
		coeffs.values.push_back(.0);
		coeffs.values.push_back(1.0);
		coeffs.values.push_back(0.0);
		viewer->addPlane(coeffs, "plane");
		viewer->resetCamera();
		ui.qvtkWidget->update();
	}
	else
	{
		viewer->removeShape("plane");
		ui.qvtkWidget->update();
	}
}
void PointCloud_ing::Cone(int state)
{
	if (state==Qt::CheckState::Checked)
	{
		pcl::ModelCoefficients coeffs;
		coeffs.values.push_back(0.3);
		coeffs.values.push_back(0.3);
		coeffs.values.push_back(0.0);
		coeffs.values.push_back(0.0);
		coeffs.values.push_back(1.0);
		coeffs.values.push_back(0.0);
		coeffs.values.push_back(5.0);
		viewer->addCone(coeffs, "cone");
		ui.qvtkWidget->update();
	}
	else
	{
		viewer->removeShape("cone");
		ui.qvtkWidget->update();
	}
}
//调整颜色函数
void PointCloud_ing::SizeLineEditChange()
{
	ui.hs_pointSize->setValue(ui.lineEdit_Size->text().toInt());
}
void PointCloud_ing::RLineEditChange()
{
	red = ui.lineEdit_R->text().toInt();
	ui.hs_R->setValue(red);
}
void PointCloud_ing::GLineEditChange()
{
	green = ui.lineEdit_G->text().toInt();
	ui.hs_G->setValue(green);
}
void PointCloud_ing::BLineEditChange()
{
	blue = ui.lineEdit_B->text().toInt();
	ui.hs_B->setValue(blue);
}
void PointCloud_ing::RandomColor()
{
	//std::default_random_engine e(time(0));
	//std::uniform_int_distribution<unsigned> u(0, 255);
	//for (size_t i = 0; i < cloud.second->size(); i++)
	//{
	//	cloud.second->points[i].r = u(e);
	//	cloud.second->points[i].g = u(e);
	//	cloud.second->points[i].b = u(e);
	//}
	////viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, u(e), u(e), u(e), "cloud");
	////pcl::visualization::PointCloudColorHandlerCustom<PointT> single_color(cloud, u(e), u(e), u(e));	
	////viewer->addPointCloud(cloud, single_color, "cloud");
	//viewer->updatePointCloud(cloud.second,cloud.first.toStdString());
	//ui.qvtkWidget->update();
}
void PointCloud_ing::RValueChange(int value)
{
	red = value;
	ui.lineEdit_R->setText(QString::number(red));
}
void PointCloud_ing::GValueChange(int value)
{
	green = value;
	ui.lineEdit_G->setText(QString::number(green));
}
void PointCloud_ing::BValueChange(int value)
{
	blue = value;
	ui.lineEdit_B->setText(QString::number(blue));
}
void PointCloud_ing::RGBValueChange()
{
	viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, red, green, blue, cloud.first.toStdString());

	viewer->updatePointCloud(cloud.second, cloud.first.toStdString());
	ui.qvtkWidget->update();
}
void PointCloud_ing::PointSizeChange(int value)
{
	
	ui.lineEdit_Size->setText(QString::number(value));
	viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, value, cloud.first.toStdString());
	ui.qvtkWidget->update();
}

void PointCloud_ing::ToPointCloudT()
{
	switch (currentCloud.pointT)
	{

	case X_Y_Z:
		using PointT = pcl::PointXYZ;
	default:
		break;
	}
	pcl::PointCloud<PointT>::Ptr cloudx(new pcl::PointCloud<PointT>);
}



//加载、删除和保存文件
void PointCloud_ing::LoadFile()
{
	QFileDialog *fileDialog = new QFileDialog(this);
	fileDialog->setNameFilter("pointcloud file(*.pcd)");
	//设置可以选择多个文件
	fileDialog->setFileMode(QFileDialog::ExistingFiles);
	QStringList fileNames;//存储多个文件路径
	QString fileName;//存储文件名，作为viewer添加点云时的ID
	if (fileDialog->exec())//fileDialog->exec()是弹出文件对话框的语句
	{		
		fileNames = fileDialog->selectedFiles();
		QTextCodec *code = QTextCodec::codecForName("GBK");//解决中文路径问题
		for (size_t i = 0; i < fileNames.size(); i++)
		{
			//解析文件路径，获取文件名
			QFileInfo fileInfo = QFileInfo(fileNames.value(i));
			fileName = fileInfo.fileName();
			clouds[fileName].reset(new pcl::PointCloud<PointT>);
			pcl::io::loadPCDFile(code->fromUnicode(fileNames.value(i)).data(), *clouds[fileName]);
			//在treeWidget中显示打开的文件名。点云数据库
			QTreeWidgetItem *imageItem1 = new QTreeWidgetItem(ui.treeWidget, QStringList(fileName));
			//控制台显示文件是否打开成功  QTextCodec::codecForLocale()->toUnicode和QString::fromLocal8Bit都行,本地编码->Unicode
			ui.textEdit_test->append(QString::fromLocal8Bit( "open pcd file succeed 成功.load ")+QString::number(clouds[fileName]->size())+" points");
						
			//添加成功打开的文件，并将ID设为文件名
			viewer->addPointCloud(clouds[fileName],fileName.toStdString());
			viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, fileName.toStdString());
			ui.hs_pointSize->setValue(2);
			viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 0, 0, 0, fileName.toStdString());
			viewer->resetCamera();//必须要有，重新设置相机参数
			ui.qvtkWidget->update();
		}		
	}
}
void PointCloud_ing::SaveFile()
{

	QString filename = QFileDialog::getSaveFileName(this, "save pointcloud file", ".", "pointcloud file(*.pcd)");
	if (pcl::io::savePCDFile(filename.toStdString(), *cloud.second) == -1)
	{
		QMessageBox mesg(QMessageBox::Icon::Warning, "Error", "save pcd file failure");
		mesg.exec();
	}
	else
	{
		ui.textEdit_test->append(filename + " open succeed.");
	}
	
}

//选中数据库中的文件时，显示属性
void PointCloud_ing::Clicked_DataBase(QTreeWidgetItem *item, int column)
{
	
	if (cloud.first==item->text(0))
	{
		return;
	}
	viewer->removeShape(cloud.first.toStdString() + "cube");
	//将选中的文件设为当前操作文件，对单个文件进行操作。此处为指针注意内存（如何设置两个以上文件的共同操作？）
	cloud.first = item->text(0);
	cloud.second = clouds[item->text(0)];
	//统一将可视化的点云大小设置为1，
	viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 2, item->text(0).toStdString());
	ui.hs_pointSize->setValue(2);
	//将选中的QTreeWidgetItem传递给保护数据
	selectedItem = item;

	//选中数据库中的文件时，显示以下属性（可以持续添加）：
	QStandardItem *item00 = new QStandardItem("Width");
	item00->setEnabled(false);
	goodsModel->setItem(0, 0, new QStandardItem("Width"));
	goodsModel->setItem(0, 1, new QStandardItem(QString::number(clouds[item->text(0)]->width)));
	QStandardItem *item10 = new QStandardItem("Height");
	item10->setEnabled(false);
	goodsModel->setItem(1, 0, item10);
	goodsModel->setItem(1, 1, new QStandardItem(QString::number(clouds[item->text(0)]->height)));
	QStandardItem *item20 = new QStandardItem("Points");
	item20->setEnabled(false);
	goodsModel->setItem(2, 0, item20);
	QStandardItem *item21 = new QStandardItem(QString::number(clouds[item->text(0)]->size()));
	goodsModel->setItem(2, 1, item21);
	QStandardItem *item30 = new QStandardItem("Point Size");
	item30->setEnabled(false);
	goodsModel->setItem(3, 0, item30);
	double value;
	viewer->getPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, value, cloud.first.toStdString());
	QStandardItem *item31 = new QStandardItem(QString::number(value));
	goodsModel->setItem(3,1,item31);

	
	viewer->resetCamera();

	PointT p1,p2;
	pcl::getMinMax3D(*cloud.second , p1, p2);
	viewer->addCube(p1.x, p2.x, p1.y, p2.y, p1.z, p2.z, 0.5, 0.5, 0.5, cloud.first.toStdString() + "cube");
	//viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_OPACITY, 0.1, cloud.first.toStdString() + "cube");
	//viewer->setShapeRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 0.5, 0.5, 0.5, cloud.first.toStdString() + "cube");
	
	viewer->setRepresentationToWireframeForAllActors();//将所有角色（对象）的视觉表示更改为线框表示。
	
	ui.qvtkWidget->update();
}

void PointCloud_ing::Clicked_Delete()
{
	//QTreeWidgetItem *item = ui.treeWidget->currentItem();
	//int column = ui.treeWidget->currentColumn();
	//ui.treeWidget->removeItemWidget(ui.treeWidget->currentItem(), 0);
	QTreeWidgetItem *item = ui.treeWidget->currentItem();
	//QTreeWidgetItem *a = item->child(0);
	int count = item->childCount();
	if (count != 0)//删除子节点，直接删除
	{
		for (int i = 0; i<count; i++)
		{
			QTreeWidgetItem *childItem = item->child(i);//删除子节点		
			viewer->removePointCloud(childItem->text(0).toStdString());
			clouds.erase(childItem->text(0));
			delete childItem;
		}
	}

	viewer->removePointCloud(item->text(0).toStdString());
	viewer->removeShape(item->text(0).toStdString() + "cube");

	clouds.erase(item->text(0));
	cloud.second.reset(new pcl::PointCloud<PointT>);
	cloud.first = QString();

	
	viewer->updatePointCloud(cloud.second);
	delete item;
	ui.qvtkWidget->update();
}