#include "PointCloud_ing.h"
#include <QtWidgets/QApplication>
#include<QSplashScreen>
#include<QPixmap>
#include <vtkOutputWindow.h>


int main(int argc, char *argv[])
{
	//��ֹVTK�ľ���
	vtkOutputWindow::SetGlobalWarningDisplay(0);
    QApplication a(argc, argv);
	QSplashScreen *splash = new QSplashScreen();
	splash->setPixmap(QPixmap(":/images/PointCloud.jpeg"));
	splash->show();
	splash->showMessage("waiting", 1, Qt::white);


    PointCloud_ing w;
	
    w.show();
	splash->finish(&w);
	delete splash;

    return a.exec();
}
